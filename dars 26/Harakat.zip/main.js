let canvas = document.createElement('canvas');
canvas.width = 1000;
canvas.height = 800;
const WIDTH = 1000;
const HEIGHT = 800;
document.body.appendChild(canvas);
let ctx = canvas.getContext('2d');
let img = new Image();
img.src = "qiz.png";

img.onload = chizish;

let i = 0;
let x = 100;
let dx = 10;
let yurish = 720;
let timer = setInterval(function(){
    ctx.clearRect(0, 0, WIDTH, HEIGHT);
    i++;
    if(i>8) i = 0;
    ctx.drawImage(img, 30 + i*63, yurish, 50, 60, x, 100, 200, 200)
    x += dx;
    if(x + 10 > WIDTH) {
        dx *= -1;
        yurish = 600;
    }

    if(x < 0){
        dx *= -1;
        yurish = 720;
    }
    
}, 50);


function chizish(){
    ctx.drawImage(img, 160, 100, 50, 60, 100, 100, 200, 200)

}